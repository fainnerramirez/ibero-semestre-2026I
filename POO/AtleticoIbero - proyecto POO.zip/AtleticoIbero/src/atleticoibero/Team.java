/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atleticoibero;

/**
 *
 * @author framir02
 */
public class Team {
    //metodo: mostrar toda la informacion del equipo: jugadores y del entrenador
    // responsable: fainner
}
